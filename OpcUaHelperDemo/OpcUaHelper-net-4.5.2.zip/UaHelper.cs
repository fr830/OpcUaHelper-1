﻿using Opc.Ua;
using Opc.Ua.Client;
using Opc.Ua.Configuration;
using System;
using System.IO;
using System.Reflection;

namespace Opc.Ua.UaHelper
{
    public class OpcUaClient
    {
        ApplicationConfiguration m_configuration;
        Session m_session;
        SessionReconnectHandler m_reconnectHandler;
        bool m_IsConnected = false;
        public OpcUaClient()
        {
            var application = new ApplicationInstance();
            application.ApplicationType = ApplicationType.Client;
            application.ConfigSectionName = Path.GetFileName(Assembly.GetExecutingAssembly().Location);

            var certificateValidator = new CertificateValidator();
            certificateValidator.CertificateValidation += new CertificateValidationEventHandler(CertificateValidator_CertificateValidation);
            SecurityConfiguration securityConfiguration = new SecurityConfiguration
            {
                AutoAcceptUntrustedCertificates = true,
                //RejectSHA1SignedCertificates = false,
                //MinimumCertificateKeySize = 1024,
            };
            certificateValidator.Update(securityConfiguration);

            application.ApplicationConfiguration = new ApplicationConfiguration
            {
                ApplicationName = application.ConfigSectionName,
                ApplicationType = ApplicationType.Client,
                CertificateValidator = certificateValidator,
                ServerConfiguration = new ServerConfiguration
                {
                    MaxSubscriptionCount = 100000,
                    MaxMessageQueueSize = 1000000,
                    MaxNotificationQueueSize = 1000000,
                    MaxPublishRequestCount = 10000000,
                },

                SecurityConfiguration = new SecurityConfiguration
                {
                    AutoAcceptUntrustedCertificates = true,
                    //RejectSHA1SignedCertificates = false,
                    //MinimumCertificateKeySize = 1024,
                },

                TransportQuotas = new TransportQuotas
                {
                    OperationTimeout = 6000000,
                    MaxStringLength = int.MaxValue,
                    MaxByteStringLength = int.MaxValue,
                    MaxArrayLength = 65535,
                    MaxMessageSize = 419430400,
                    MaxBufferSize = 65535,
                    ChannelLifetime = -1,
                    SecurityTokenLifetime = -1
                },
                ClientConfiguration = new ClientConfiguration
                {
                    DefaultSessionTimeout = -1,
                    MinSubscriptionLifetime = -1,
                },
                DisableHiResClock = true
            };

            m_configuration = application.ApplicationConfiguration;
        }


        ~OpcUaClient()
        {
            Disconnect();
        }


        public void Connect(string Url)
        {
            if (string.IsNullOrEmpty(Url)) throw new ArgumentNullException("UaServer");

            if (m_configuration == null) throw new ArgumentNullException("m_configuration");

            // select the best endpoint.
            EndpointDescription endpointDescription = SelectEndpoint(Url, false);

            EndpointConfiguration endpointConfiguration = EndpointConfiguration.Create(m_configuration);
            ConfiguredEndpoint endpoint = new ConfiguredEndpoint(null, endpointDescription, endpointConfiguration);

            m_session = Session.Create(
                m_configuration,
                endpoint,
                false,
                false,
                m_configuration.ApplicationName,
                60000,
                new UserIdentity(new AnonymousIdentityToken()),
                new string[] { });

            // set up keep alive callback.
            m_session.KeepAlive += new KeepAliveEventHandler(Session_KeepAlive);

            m_IsConnected = true;
        }


        public void Disconnect()
        {
            // stop any reconnect operation.
            if (m_reconnectHandler != null)
            {
                m_reconnectHandler.Dispose();
                m_reconnectHandler = null;
            }

            // disconnect any existing session.
            if (m_session != null)
            {
                m_session.Close(10000);
                m_session = null;
            }
            m_IsConnected = false;
        }


        public string ReadNode(string NodeId)
        {
            return ReadNode(NodeId, Attributes.Value)?.ToString();
        }

        object ReadNode(string NodeId, uint AttributeId)
        {
            DataValueCollection results = null;
            DiagnosticInfoCollection diagnosticInfos = new DiagnosticInfoCollection();

            var readNode = new ReadValueId
            {
                NodeId = NodeId,
                AttributeId = AttributeId
            };

            m_session.Read(
          null,
          0,
          TimestampsToReturn.Neither,
          new ReadValueIdCollection { readNode },
          out results,
          out diagnosticInfos);

            if (results != null && results.Count == 1 && DataValue.IsGood(results[0]))
            {
                return results[0].Value;
            }
            else
            {
                return null;
            }
        }

        public bool WriteNode(string NodeId, string Value)
        {
            var typeNodeId = ReadNode(NodeId, Attributes.DataType);
            BuiltInType builtinType = Opc.Ua.TypeInfo.GetBuiltInType(typeNodeId as NodeId, m_session.TypeTree);

            WriteValue writeNode = new WriteValue()
            {
                NodeId = NodeId,
                AttributeId = Attributes.Value,
                Value = new DataValue
                {
                    Value = new Variant(Opc.Ua.TypeInfo.Cast(Value, builtinType)),
                    StatusCode = StatusCodes.Good,
                    ServerTimestamp = DateTime.MinValue,
                    SourceTimestamp = DateTime.MinValue
                }
            };

            StatusCodeCollection results = new StatusCodeCollection();
            DiagnosticInfoCollection diagnosticInfos = new DiagnosticInfoCollection();

            m_session.Write(
                null,
                new WriteValueCollection
            {
                writeNode
            },
                out results,
                out diagnosticInfos);

            if (StatusCode.IsBad(results[0]))
            {
                throw new ServiceResultException(results[0]);
            }

            return !StatusCode.IsBad(results[0]);
        }

        void Session_KeepAlive(Session session, KeepAliveEventArgs e)
        {

            // check for events from discarded sessions.
            if (!Object.ReferenceEquals(session, m_session))
            {
                return;
            }

            if (ServiceResult.IsBad(e.Status))
            {
                m_IsConnected = false;

                m_reconnectHandler = new SessionReconnectHandler();
                m_reconnectHandler.BeginReconnect(m_session, 10000, Server_ReconnectComplete);
            }
        }

        /// <summary>
        /// Handles a reconnect event complete from the reconnect handler.
        /// </summary>
        void Server_ReconnectComplete(object sender, EventArgs e)
        {
            // ignore callbacks from discarded objects.
            if (!Object.ReferenceEquals(sender, m_reconnectHandler))
            {
                return;
            }


            m_session = m_reconnectHandler.Session;
            m_reconnectHandler.Dispose();
            m_reconnectHandler = null;

            m_IsConnected = true;
        }


        /// <summary>
        /// 证书不授信时回调函数
        /// </summary>
        /// <param name="validator"></param>
        /// <param name="e"></param>
        void CertificateValidator_CertificateValidation(CertificateValidator validator, CertificateValidationEventArgs eventArgs)
        {
            if (ServiceResult.IsGood(eventArgs.Error))
                eventArgs.Accept = true;
            else if (eventArgs.Error.StatusCode.Code == StatusCodes.BadCertificateUntrusted)
                eventArgs.Accept = true;
            else
                throw new Exception(string.Format("Failed to validate certificate with error code {0}: {1}", eventArgs.Error.Code, eventArgs.Error.AdditionalInfo));
        }
        /// <summary>
        /// Finds the endpoint that best matches the current settings.
        /// </summary>
        /// <param name="discoveryUrl">The discovery URL.</param>
        /// <param name="useSecurity">if set to <c>true</c> select an endpoint that uses security.</param>
        /// <returns>The best available endpoint.</returns>
        EndpointDescription SelectEndpoint(string discoveryUrl, bool useSecurity)
        {
            // needs to add the '/discovery' back onto non-UA TCP URLs.
            if (!discoveryUrl.StartsWith(Opc.Ua.Utils.UriSchemeOpcTcp))
            {
                if (!discoveryUrl.EndsWith("/discovery"))
                {
                    discoveryUrl += "/discovery";
                }
            }

            // parse the selected URL.
            Uri uri = new Uri(discoveryUrl);

            // set a short timeout because this is happening in the drop down event.
            EndpointConfiguration configuration = EndpointConfiguration.Create();
            configuration.OperationTimeout = 5000;

            EndpointDescription selectedEndpoint = null;

            // Connect to the server's discovery endpoint and find the available configuration.
            using (DiscoveryClient client = DiscoveryClient.Create(uri, configuration))
            {
                EndpointDescriptionCollection endpoints = client.GetEndpoints(null);

                // select the best endpoint to use based on the selected URL and the UseSecurity checkbox. 
                for (int ii = 0; ii < endpoints.Count; ii++)
                {
                    EndpointDescription endpoint = endpoints[ii];

                    // check for a match on the URL scheme.
                    if (endpoint.EndpointUrl.StartsWith(uri.Scheme))
                    {
                        // check if security was requested.
                        if (useSecurity)
                        {
                            if (endpoint.SecurityMode == MessageSecurityMode.None)
                            {
                                continue;
                            }
                        }
                        else
                        {
                            if (endpoint.SecurityMode != MessageSecurityMode.None)
                            {
                                continue;
                            }
                        }

                        // pick the first available endpoint by default.
                        if (selectedEndpoint == null)
                        {
                            selectedEndpoint = endpoint;
                        }

                        // The security level is a relative measure assigned by the server to the 
                        // endpoints that it returns. Clients should always pick the highest level
                        // unless they have a reason not too.
                        if (endpoint.SecurityLevel > selectedEndpoint.SecurityLevel)
                        {
                            selectedEndpoint = endpoint;
                        }
                    }
                }

                // pick the first available endpoint by default.
                if (selectedEndpoint == null && endpoints.Count > 0)
                {
                    selectedEndpoint = endpoints[0];
                }
            }

            // if a server is behind a firewall it may return URLs that are not accessible to the client.
            // This problem can be avoided by assuming that the domain in the URL used to call 
            // GetEndpoints can be used to access any of the endpoints. This code makes that conversion.
            // Note that the conversion only makes sense if discovery uses the same protocol as the endpoint.

            Uri endpointUrl = Opc.Ua.Utils.ParseUri(selectedEndpoint.EndpointUrl);

            if (endpointUrl != null && endpointUrl.Scheme == uri.Scheme)
            {
                UriBuilder builder = new UriBuilder(endpointUrl);
                builder.Host = uri.DnsSafeHost;
                builder.Port = uri.Port;
                selectedEndpoint.EndpointUrl = builder.ToString();
            }

            // return the selected endpoint.
            return selectedEndpoint;
        }

    }
}
